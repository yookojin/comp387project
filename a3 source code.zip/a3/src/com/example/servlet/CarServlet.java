package com.example.servlet;


import com.example.entity.Car;
import com.example.entity.Product;
import com.example.entity.User;
import com.example.service.CarService;
import com.example.service.ProductService;
import com.example.utils.R;
import com.example.vo.CarVO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/cart/*")
public class CarServlet extends HttpServlet {

    private CarService carService = new CarService();
    private ProductService productService = new ProductService();


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        String method = req.getParameter("method");
        try {
            if ("list".equals(method)) {
                list(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        String pathInfo = req.getPathInfo();
        if (pathInfo != null && pathInfo.split("/").length == 3){
            String[] split = pathInfo.split("/");
            try {
                delete(req, resp, split[2]);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            return;
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        String method = req.getParameter("method");

        String pathInfo = req.getPathInfo();
        if (pathInfo != null && pathInfo.split("/").length == 3){
            String[] split = pathInfo.split("/");
            try {
                add(req, resp, split[2]);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            return;
        }

        try {
            if ("update".equals(method)) {
                update(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void list(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        Car car = new Car();

        String userId = req.getParameter("userId");
        if (userId != null && !userId.equals("")) {
            car.setUserId(Integer.parseInt(userId));
        }

        List<CarVO> carVOList = carService.carList(car);
        resp.getWriter().write(R.ok(carVOList));
    }

    private void add(HttpServletRequest req, HttpServletResponse resp, String slug) throws Exception {
        Car car = new Car();
        car.setNums(Integer.parseInt(req.getParameter("nums")));
        car.setUserId(Integer.parseInt(req.getParameter("userId")));

        Product product = new Product();
        product.setSlug(slug);
        Product p = productService.productList(product).get(0);
        car.setProductId(p.getId());

        boolean addCar = carService.addCar(car);
        resp.getWriter().write(R.ok(addCar));
    }

    private void update(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        Car car = new Car();
        car.setId(Integer.parseInt(req.getParameter("id")));
        car.setNums(Integer.parseInt(req.getParameter("nums")));
        car.setUserId(Integer.parseInt(req.getParameter("userId")));
        car.setProductId(Integer.parseInt(req.getParameter("productId")));
        boolean updateCar = carService.updateCar(car);
        resp.getWriter().write(R.ok(updateCar));
    }

    private void delete(HttpServletRequest req, HttpServletResponse resp, String slug) throws Exception {
        Product product = new Product();
        product.setSlug(slug);
        List<Product> productList = productService.productList(product);
        Car car = new Car();

        User user = (User) req.getSession().getAttribute("user");
        car.setUserId(user.getId());
        car.setProductId(productList.get(0).getId());
        List<CarVO> carVOS = carService.carList(car);
        Integer carId = carVOS.get(0).getId();
        car.setId(carId);
        boolean delete = carService.delete(car);
        resp.getWriter().write(R.ok(delete));
    }


}
