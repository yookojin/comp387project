package com.example.servlet;



import com.example.entity.User;
import com.example.service.UserService;
import com.example.utils.R;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;


@WebServlet("/user/*")
public class UserServlet extends HttpServlet {

    private UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        String method = req.getParameter("method");
        try {
            if ("info".equals(method)) {
                info(req, resp);
            } else if ("list".equals(method)) {
                list(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    private void list(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        User user = new User();
        List<User> userList = userService.userList(user);
        resp.getWriter().write(R.ok(userList));
    }

    private void info(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User userEntity = (User) req.getSession().getAttribute("user");
        resp.getWriter().write(R.ok(userEntity));
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        String method = req.getParameter("method");
        try {
            if ("login".equals(method)) {
                login(req, resp);
            } else if ("update".equals(method)) {
                update(req, resp);
            } else if ("register".equals(method)) {
                register(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void login(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String role = req.getParameter("role");
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setRole(role);
        User userEntity = userService.login(user);
        if (userEntity != null) {
            req.getSession().setAttribute("user", userEntity);
            resp.getWriter().write(R.ok(userEntity));
        } else {
            resp.getWriter().write(R.error(500, "password or account error"));
        }
    }

    private void register(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String nickname = req.getParameter("nickname");
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setNickname(nickname);
        user.setRole("user");
        boolean b = userService.addUser(user);
        if (b) {
            resp.getWriter().write(R.ok("success"));
        } else {
            resp.getWriter().write(R.error(500, "error"));
        }
    }

    private void update(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        String password = req.getParameter("password");
        User user = new User();
        user.setPassword(password);
        user.setId(Integer.valueOf(req.getParameter("id")));
        user.setUsername(req.getParameter("username"));
        user.setRole(req.getParameter("role"));
        user.setNickname(req.getParameter("nickname"));
        boolean result = userService.updateUser(user);
        resp.getWriter().write(R.ok(result));
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        String pathInfo = req.getPathInfo();
        if (pathInfo != null && pathInfo.split("/").length == 3){
            String[] split = pathInfo.split("/");
            try {
                delete(req, resp, Integer.valueOf(split[2]));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            return;
        }
    }

    private void delete(HttpServletRequest req, HttpServletResponse resp, Integer id) throws Exception {
        User user = new User();
        user.setId(id);
        boolean delete = userService.delete(user);
        resp.getWriter().write(R.ok(delete));
    }

}
