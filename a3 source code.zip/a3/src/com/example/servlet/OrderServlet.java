package com.example.servlet;


import com.example.entity.Orders;
import com.example.service.OrdersService;
import com.example.service.OrdersService;
import com.example.service.ProductService;
import com.example.utils.R;
import com.example.vo.OrdersVO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet("/orders/*")
public class OrderServlet extends HttpServlet {

    private OrdersService ordersService = new OrdersService();


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        String method = req.getParameter("method");

        String pathInfo = req.getPathInfo();
        if ((pathInfo == null || pathInfo.equals("/")) && method == null) {
            resp.sendRedirect("/front/order.html");
            return;
        }
        if (pathInfo != null && pathInfo.split("/").length == 2){
            String[] split = pathInfo.split("/");
            String ordersId = split[1];
            Orders orders = new Orders();
            orders.setId(Integer.parseInt(ordersId));;
            List<OrdersVO> ordersVOList = ordersService.ordersList(orders);
            resp.getWriter().write(R.ok(ordersVOList));
            return;
        }


        try {
            if ("list".equals(method)) {
                list(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        String method = req.getParameter("method");
        try {
            if ("update".equals(method)) {
                update(req, resp);
            } else if ("add".equals(method)) {
                add(req, resp);
            } else if ("delete".equals(method)) {
                delete(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void list(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        Orders orders = new Orders();
        String userId = req.getParameter("userId");
        if (userId != null && !userId.equals("")) {
            orders.setUserId(Integer.parseInt(userId));
        }
        List<OrdersVO> ordersVOList = ordersService.ordersList(orders);
        resp.getWriter().write(R.ok(ordersVOList));
    }

    private void add(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        int userId = Integer.parseInt(req.getParameter("userId"));
        String address = req.getParameter("address");
        boolean addOrders = ordersService.addOrdersByUserId(userId, address);
        resp.getWriter().write(R.ok(addOrders));
    }

    private void update(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        Orders orders = new Orders();
        orders.setId(Integer.parseInt(req.getParameter("id")));
        orders.setNo(req.getParameter("no"));
        orders.setAddress(req.getParameter("address"));
        orders.setUserId(Integer.parseInt(req.getParameter("userId")));
        orders.setTrackingNumber(req.getParameter("trackingNumber"));
        orders.setCreateTime(new Date());
        orders.setNums(Integer.parseInt(req.getParameter("nums")));

        int status = Integer.parseInt(req.getParameter("status"));
        orders.setStatus(status);
        if (status == 2) {
            orders.setTrackingNumber("C" + System.currentTimeMillis());
        }

        boolean updateOrders = ordersService.updateOrders(orders);
        resp.getWriter().write(R.ok(updateOrders));
    }

    private void delete(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        Orders orders = new Orders();
        orders.setId(Integer.parseInt(req.getParameter("id")));
        boolean delete = ordersService.delete(orders);
        resp.getWriter().write(R.ok(delete));
    }


}
