package com.example.servlet;


import com.example.entity.Product;
import com.example.entity.User;
import com.example.service.ProductService;
import com.example.service.UserService;
import com.example.utils.R;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/products/*")
public class ProductServlet extends HttpServlet {

    private ProductService productService = new ProductService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        String method = req.getParameter("method");

        String pathInfo = req.getPathInfo();
        if ((pathInfo == null || pathInfo.equals("/")) && method == null) {
            resp.sendRedirect("/front/index.html");
            return;
        }
        if (pathInfo != null && pathInfo.split("/").length == 2){
            String[] split = pathInfo.split("/");
            resp.sendRedirect("/front/detail.html?slug=" + split[1]);
            return;
        }


        try {
            if ("list".equals(method)) {
                list(req, resp);
            } else if ("productBySlug".equals(method)) {
                productBySlug(req, resp);
            } else if ("productBySku".equals(method)) {
                productBySku(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    private void productBySku(HttpServletRequest req, HttpServletResponse resp) throws Exception{
        Product product = new Product();
        String sku = req.getParameter("sku");
        product.setSku(sku);
        List<Product> productList = productService.productList(product);
        resp.getWriter().write(R.ok(productList.size() > 0 ? productList.get(0) : null));
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        String method = req.getParameter("method");

        String pathInfo = req.getPathInfo();
        if (pathInfo != null && pathInfo.split("/").length == 2){
            String[] split = pathInfo.split("/");
            try {
                update(req, resp, split[1]);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            return;
        }

        try {
             if ("add".equals(method)) {
                add(req, resp);
            } else if ("delete".equals(method)) {
                delete(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void productBySlug(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        Product product = new Product();
        String slug = req.getParameter("slug");
        product.setSlug(slug);
        List<Product> productList = productService.productList(product);
        resp.getWriter().write(R.ok(productList.size() > 0 ? productList.get(0) : null));
    }

    private void list(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        Product product = new Product();
        List<Product> productList = productService.productList(product);
        resp.getWriter().write(R.ok(productList));
    }

    private void add(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        Product product = new Product();
        product.setName(req.getParameter("name"));
        product.setSupplier(req.getParameter("supplier"));
        product.setDescription(req.getParameter("description"));
        product.setSlug(req.getParameter("slug"));
        product.setSku(req.getParameter("sku"));
        boolean addProduct = productService.addProduct(product);
        resp.getWriter().write(R.ok(addProduct));
    }

    private void update(HttpServletRequest req, HttpServletResponse resp, String slug) throws Exception {
        Product product = new Product();
        product.setId(Integer.parseInt(req.getParameter("id")));
        product.setName(req.getParameter("name"));
        product.setSupplier(req.getParameter("supplier"));
        product.setDescription(req.getParameter("description"));
        product.setSlug(slug);
        product.setSku(req.getParameter("sku"));
        boolean updateProduct = productService.updateProduct(product);
        resp.getWriter().write(R.ok(updateProduct));
    }

    private void delete(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        Product product = new Product();
        product.setId(Integer.parseInt(req.getParameter("id")));
        boolean delete = productService.delete(product);
        resp.getWriter().write(R.ok(delete));
    }


}
