package com.example.test;

import com.example.entity.Orders;
import com.example.entity.User;
import com.example.service.OrdersService;
import com.example.service.UserService;
import org.junit.Test;

import java.util.Date;

public class UnitTest {

    @Test
    public void SetOrderOwner() {
        OrdersService ordersService = new OrdersService();
        Orders orders = new Orders();
        orders.setId(1);
        orders.setNo("N1701126240051");
        orders.setAddress("beijin");
        orders.setTrackingNumber(null);
        orders.setCreateTime(new Date());
        orders.setStatus(1);
        orders.setProductId(1);
        orders.setNums(1);
        orders.setUserId(4);

        boolean b = ordersService.updateOrders(orders);
        if (b) {
            System.out.println("update success");
        } else {
            System.out.println("update error");
        }
    }

    @Test
    public void SetPasscode() {
        UserService userService = new UserService();
        User user = new User();
        user.setId(4);
        user.setPassword("1234567");
        user.setUsername("test@qq.com");
        user.setNickname("Test");
        user.setRole("user");
        boolean b = userService.updateUser(user);
        if (b) {
            System.out.println("update success");
        } else {
            System.out.println("update error");
        }
    }
}
