package com.example.utils;

import java.sql.*;
import java.util.Objects;

public class DBUtil {


    private static String url = "jdbc:sqlite:D:\\JavaEn\\sqlite\\data\\test.db";

    static {
        try {
            Driver driver = (Driver) Class.forName("org.sqlite.JDBC").newInstance();
            DriverManager.registerDriver(driver);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    public static Connection getConnection(String url){
        try {
            return DriverManager.getConnection(url);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static Connection getConnection() {
        return getConnection(url);
    }

    public static void close(Connection connection, Statement statement, ResultSet resultSet) {
        try {
            if (Objects.nonNull(resultSet)) resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            if (Objects.nonNull(statement)) statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            if (Objects.nonNull(connection)) connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}