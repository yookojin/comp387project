package com.example.utils;

import java.lang.reflect.Field;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class JdbcTemplate {

    /**
     * 添加
     * @param t 实体
     * @return
     * @param <T>
     */
    public <T> boolean add(T t) {
        Class<?> clz = t.getClass();
        Field[] fields = clz.getDeclaredFields();
        String tableName = clz.getSimpleName();
        Object[] args = new Object[fields.length];

        boolean r = execute(() -> true, () -> {
            try {
                String preSql = "insert into %s (%s) values(%s)";
                StringBuilder s2Builder = new StringBuilder();
                StringBuilder s3Builder = new StringBuilder();
                for (int i = 0; i < fields.length; i++) {
                    //开启暴力反射
                    fields[i].setAccessible(true);
                    args[i] = fields[i].get(t);
                    s2Builder.append(fields[i].getName());
                    s3Builder.append("?");
                    if (fields.length - i == 1) {
                        break;
                    }
                    s2Builder.append(",");
                    s3Builder.append(",");
                }
                preSql = String.format(preSql, tableName, s2Builder, s3Builder);
                return preSql;
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }, (o) -> {
            Integer result = (Integer) o;
            return result != 0 ? true : false;
        }, args);
        return r;
    }


    /**
     * 根据id更新数据
     * @param t 实体
     * @return
     * @param <T>
     */
    public <T> boolean update(T t) {
        Class<?> clz = t.getClass();
        Field[] fields = clz.getDeclaredFields();
        String tableName = clz.getSimpleName();
        Object[] args = new Object[fields.length];
        boolean r = execute(() -> true, () -> {
            try {
                List<Field> fieldList = Arrays.stream(fields).filter(field ->
                        !field.getName().equals("id")
                ).collect(Collectors.toList());

                String preSql = "update %s set %s where %s=%s";
                StringBuilder s2Builder = new StringBuilder();
                for (int i = 0; i < fieldList.size(); i++) {
                    Field field = fieldList.get(i);
                    //开启暴力反射
                    field.setAccessible(true);
                    args[i] = field.get(t);
                    s2Builder.append(field.getName());
                    s2Builder.append("=?");
                    if (fieldList.size() - i == 1) {
                        break;
                    }
                    s2Builder.append(",");
                }
                Field idField = clz.getDeclaredField("id");
                idField.setAccessible(true);
                args[args.length - 1] = idField.get(t);
                preSql = String.format(preSql, tableName, s2Builder, idField.getName(), "?");
                return preSql;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }, o -> {
            Integer result = (Integer) o;
            return result != 0 ? true : false;
        }, args);
        return r;
    }

    public <T> List<T> query(Class<T> clz, Map<String, Object> params) {
        Field[] fields = clz.getDeclaredFields();
        String tableName = clz.getSimpleName();
        List<String> keyList = params.keySet().stream().collect(Collectors.toList());
        Object[] args = new Object[keyList.size()];
        List<T> r = execute(() -> false, () -> {

            String preSql = "select %s from %s where 1=1  %s";
            StringBuilder s1Builder = new StringBuilder();
            for (int i = 0; i < fields.length; i++) {
                s1Builder.append(fields[i].getName());
                if (fields.length - i == 1) {
                    break;
                }
                s1Builder.append(",");
            }

            StringBuilder s3Builder = new StringBuilder();
            for (int i = 0; i < keyList.size(); i++) {
                args[i] = params.get(keyList.get(i));
                s3Builder.append(" and ");
                s3Builder.append(keyList.get(i));
                s3Builder.append("= ?");
            }
            preSql = String.format(preSql, s1Builder,tableName,  s3Builder);
            return preSql;
        }, (result) -> {
            try {
                ResultSet resultSet = (ResultSet) result;
                List<T> list = new ArrayList<>();
                ResultSetMetaData metaData = resultSet.getMetaData();
                int columnCount = metaData.getColumnCount();

                while (resultSet.next()) {
                    T t = clz.newInstance();
                    for (int i = 0; i < columnCount; i++) {
                        String columnName = metaData.getColumnName(i + 1);
                        Object columnValue = resultSet.getObject(i + 1);
                        Field declaredField = clz.getDeclaredField(columnName);
                        declaredField.setAccessible(true);
                        if (declaredField.getType().equals(Date.class) ) {
                            columnValue = new Date(Long.parseLong(columnValue.toString()));
                        }
                        declaredField.set(t, columnValue);
                    }
                    list.add(t);
                }
                return list;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }, args);
        return r;
    }

    /**
     * sql执行的模板方法
     *
     * @param booleanSupplier          {@code true} if {@code booleanSupplier} 执行update
     *                                 {@code false} if {@code booleanSupplier} 执行query
     * @param preprocessingSQLSupplier 预处sql提供器
     * @param resultCallBack           结果集处理回调函数
     * @param args                     填充占位符的参数
     * @param <T>                      结果泛型
     * @return sql执行的结果
     * @throws SQLException
     */
    public <T> T execute(Supplier<Boolean> booleanSupplier, Supplier<String> preprocessingSQLSupplier, Function<Object, T> resultCallBack, Object... args) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        T r;
        ResultSet resultSet = null;
        try {
            //1.获取连接对象
            connection = DBUtil.getConnection();
            //2.预处理sql
            String preSql = preprocessingSQLSupplier.get();
            //3.获取preparedStatement对象
            preparedStatement = connection.prepareStatement(preSql);
            //4.填充占位符
            for (int i = 0; i < args.length; i++) {
                preparedStatement.setObject(i + 1, args[i]);
            }
            //5.执行sql
            int result;
            resultSet = null;
            if (booleanSupplier.get()) {
                result = preparedStatement.executeUpdate();
                //6.处理结果集合
                r = resultCallBack.apply(result);
            } else {
                //6.处理结果集合
                resultSet = preparedStatement.executeQuery();
                r = resultCallBack.apply(resultSet);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, preparedStatement, resultSet);
        }
        return r;
    }



    public <T> boolean delete(T t) {
        Class<?> clz = t.getClass();
        String tableName = clz.getSimpleName();
        String preSql = "delete from %s where id = %d";
        Field declaredField = null;
        try {
            declaredField = clz.getDeclaredField("id");
            declaredField.setAccessible(true);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        }
        try {
            preSql = String.format(preSql, tableName, declaredField.get(t));
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        //1.获取连接对象
        Connection connection = DBUtil.getConnection();
        //3.获取preparedStatement对象
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement(preSql);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        int i = 0;
        try {
            i = preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return i>0;
    }

}
