package com.example.utils;

import com.alibaba.fastjson2.JSON;

public class R {
    private Integer code;

    private Object data;

    private String msg;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public static String ok(Object data) {
        R r = new R();
        r.code = 200;
        r.data = data;
        return JSON.toJSONString(r);
    }

    public static String error(Integer code, String msg) {
        R r = new R();
        r.code = code;
        r.msg = msg;
        return JSON.toJSONString(r);
    }
}
