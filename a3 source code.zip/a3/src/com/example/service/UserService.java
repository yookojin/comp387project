package com.example.service;

import com.example.entity.User;
import com.example.utils.JdbcTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserService {
    JdbcTemplate jdbcTemplate = new JdbcTemplate();

    public boolean addUser(User user) {
       return jdbcTemplate.add(user);
    }

    public boolean updateUser(User user) {
        return jdbcTemplate.update(user);
    }

    public List<User> userList(User user) {
        Map<String, Object> map = new HashMap<>();
        return jdbcTemplate.query(User.class, map);
    }

    public boolean delete(User user) {
        return jdbcTemplate.delete(user);
    }

    public User login(User user) {
        Map<String, Object> map = new HashMap<>();
        map.put("username", user.getUsername());
        map.put("password", user.getPassword());
        map.put("role", user.getRole());
        List<User> query = jdbcTemplate.query(User.class, map);
        return query.size() > 0 ? query.get(0) : null;
    }
}
