package com.example.service;

import com.example.entity.Car;
import com.example.entity.Orders;
import com.example.entity.Product;
import com.example.entity.User;
import com.example.utils.JdbcTemplate;
import com.example.vo.CarVO;
import com.example.vo.OrdersVO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CarService {
    JdbcTemplate jdbcTemplate = new JdbcTemplate();

    private UserService userService = new UserService();
    private ProductService productService = new ProductService();

    public boolean addCar(Car car) {
        Car car1 = new Car();
        car1.setUserId(car.getUserId());
        car1.setProductId(car.getProductId());
        List<CarVO> carVOS = carList(car1);
        if (carVOS.size() > 0) {
            car.setId(carVOS.get(0).getId());
            car.setNums(carVOS.get(0).getNums() + 1);
            return updateCar(car);
        } else {
            return jdbcTemplate.add(car);
        }
    }

    public boolean updateCar(Car car) {
        return jdbcTemplate.update(car);
    }

    public List<CarVO> carList(Car car) {
        Map<String, Object> map = new HashMap<>();
        if (car.getId() != null) {
            map.put("id", car.getId());
        }
        if (car.getUserId() != null) {
            map.put("userId", car.getUserId());
        }
        if (car.getProductId() != null) {
            map.put("productId", car.getProductId());
        }
        List<Car> carList = jdbcTemplate.query(Car.class, map);

        List<CarVO> carVoList = new ArrayList<>();
        for (Car item : carList) {
            CarVO carVO = new CarVO();
            carVO.setId(item.getId());
            carVO.setProductId(item.getProductId());
            carVO.setUserId(item.getUserId());
            carVO.setNums(item.getNums());

            Product product = new Product();
            product.setId(carVO.getProductId());
            List<Product> productList = productService.productList(product);
            carVO.setProduct(productList.get(0));


            User user = new User();
            user.setId(carVO.getUserId());
            List<User> userList = userService.userList(user);
            carVO.setUser(userList.get(0));

            carVoList.add(carVO);

        }
        return carVoList;
    }

    public boolean delete(Car car) {
        return jdbcTemplate.delete(car);
    }
}
