package com.example.service;

import com.example.entity.Product;
import com.example.utils.JdbcTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductService {
    JdbcTemplate jdbcTemplate = new JdbcTemplate();

    public boolean addProduct(Product product) {
       return jdbcTemplate.add(product);
    }

    public boolean updateProduct(Product product) {
        return jdbcTemplate.update(product);
    }

    public List<Product> productList(Product product) {
        Map<String, Object> map = new HashMap<>();
        if (product.getId() != null) {
            map.put("id", product.getId());
        }
        if (product.getSlug() != null) {
            map.put("slug", product.getSlug());
        }
        if (product.getSku() != null) {
            map.put("sku", product.getSku());
        }
        return jdbcTemplate.query(Product.class, map);
    }

    public boolean delete(Product product) {
        return jdbcTemplate.delete(product);
    }

}
