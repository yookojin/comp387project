package com.example.service;

import com.example.entity.Car;
import com.example.entity.Orders;
import com.example.entity.Product;
import com.example.entity.User;
import com.example.utils.JdbcTemplate;
import com.example.vo.CarVO;
import com.example.vo.OrdersVO;

import java.util.*;

public class OrdersService {
    JdbcTemplate jdbcTemplate = new JdbcTemplate();

    private ProductService productService = new ProductService();
    private UserService userService = new UserService();
    private CarService carService = new CarService();

    public boolean addOrders(Orders orders) {
       return jdbcTemplate.add(orders);
    }

    public boolean updateOrders(Orders orders) {
        return jdbcTemplate.update(orders);
    }

    public List<OrdersVO> ordersList(Orders orders) {
        Map<String, Object> map = new HashMap<>();
        if (orders.getId() != null) {
            map.put("id", orders.getId());
        }
        if (orders.getUserId() != null) {
            map.put("userId", orders.getUserId());
        }
        if (orders.getProductId() != null) {
            map.put("productId", orders.getProductId());
        }

        List<Orders> ordersList = jdbcTemplate.query(Orders.class, map);
        List<OrdersVO> ordersVoList = new ArrayList<>();
        for (Orders item : ordersList) {
            OrdersVO ordersVO = new OrdersVO();
            ordersVO.setId(item.getId());
            ordersVO.setAddress(item.getAddress());
            ordersVO.setUserId(item.getUserId());
            ordersVO.setNo(item.getNo());
            ordersVO.setTrackingNumber(item.getTrackingNumber());
            ordersVO.setCreateTime(item.getCreateTime());
            ordersVO.setStatus(item.getStatus());
            ordersVO.setProductId(item.getProductId());
            ordersVO.setNums(item.getNums());

            Product product = new Product();
            product.setId(ordersVO.getProductId());
            List<Product> productList = productService.productList(product);
            ordersVO.setProduct(productList.get(0));


            User user = new User();
            user.setId(ordersVO.getUserId());
            List<User> userList = userService.userList(user);
            ordersVO.setUser(userList.get(0));

            ordersVoList.add(ordersVO);
        }
        return ordersVoList;
    }

    public boolean delete(Orders orders) {
        return jdbcTemplate.delete(orders);
    }

    public boolean addOrdersByUserId(int userId, String address) {
        Car car = new Car();
        car.setUserId(userId);
        List<CarVO> carVOS = carService.carList(car);

        for (CarVO carVO : carVOS) {
            Orders orders = new Orders();
            orders.setStatus(1);
            orders.setUserId(userId);
            orders.setAddress(address);
            orders.setNo("N" + System.currentTimeMillis());
            orders.setProductId(carVO.getProductId());
            orders.setCreateTime(new Date());
            orders.setNums(carVO.getNums());
            addOrders(orders);

            car.setId(carVO.getId());
            carService.delete(car);
        }
        return true;
    }
}
